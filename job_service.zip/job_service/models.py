from sqlalchemy import Column, Integer, String, Text, Float, Boolean
from database import Base
from sqlalchemy.ext.hybrid import hybrid_property

class Job(Base):

    __tablename__ = "jobs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    owner_id=Column(Integer,nullable=False)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    skills = Column(Text, nullable=False)
    experience = Column(String, nullable=False)
    education = Column(String, nullable=False)
    languages = Column(String, nullable=True)
    contract_type = Column(String, nullable=False)
    salary = Column(Float, nullable=True)
    location = Column(String, nullable=True)
    is_published = Column(Boolean, default=False)

    @hybrid_property
    def text(self):
        # Générer dynamiquement le champ text
        return f"{self.title} {self.description} {self.skills} {self.experience} {self.education or ''}"
