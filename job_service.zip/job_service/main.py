from fastapi import FastAPI
from database import Base, engine
from routes import router
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

# Configuration CORS
origins = [
    "http://localhost:3000",  # React en local
    "http://localhost:5173",  # Vite.js en local
    "http://127.0.0.1:3000",  # React en local sur IP
    "http://127.0.0.1:5173",  # Vite.js en local sur IP
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],  # Autorise toutes les méthodes HTTP
    allow_headers=["*"],  # Autorise tous les headers
)

# Création des tables de la base de données
Base.metadata.create_all(bind=engine)

# Inclusion des routes
app.include_router(router)
