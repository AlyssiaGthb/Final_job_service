from fastapi import APIRouter, HTTPException, Depends, Header, Response
from sqlalchemy.orm import Session
from schemas import JobCreate, JobUpdate, JobPreview
from models import Job
from database import get_db
from utils import verify_user_exists
from fpdf import FPDF
import os

router = APIRouter()

@router.post("/job/create")
def create_job(job_data: JobCreate, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "recruiter":
        raise HTTPException(status_code=403, detail="Access restricted to recruiters only")

    new_job = Job(**job_data.dict(), owner_id=user_info.get("id"))
    db.add(new_job)
    db.commit()
    db.refresh(new_job)
    return new_job

@router.put("/job/customize")
def customize_job(job_id: int, job_data: JobUpdate, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "recruiter":
        raise HTTPException(status_code=403, detail="Access restricted to recruiters only")

    job = db.query(Job).filter(Job.id == job_id, Job.owner_id == user_info.get("id")).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found or access unauthorized")

    for key, value in job_data.dict(exclude_unset=True).items():
        setattr(job, key, value)
    db.commit()
    db.refresh(job)
    return {"message": "Job updated successfully"}

@router.get("/job/preview", response_model=JobPreview)
def preview_job(job_id: int, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    '''if user_info.get("role") != "recruiter":
        raise HTTPException(status_code=403, detail="Access restricted to recruiters only")
'''
    job = db.query(Job).filter(Job.id == job_id, Job.owner_id == user_info.get("id")).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found or access unauthorized")
    return job

@router.post("/job/publish")
def publish_job(job_id: int, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "recruiter":
        raise HTTPException(status_code=403, detail="Access restricted to recruiters only")

    job = db.query(Job).filter(Job.id == job_id, Job.owner_id == user_info.get("id")).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found or access unauthorized")

    job.is_published = True
    db.commit()
    return {"message": "Job published successfully"}

@router.delete("/job/{id}")
def delete_job(id: int, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    '''if user_info.get("role") != "recruiter":
        raise HTTPException(status_code=403, detail="Access restricted to recruiters only")
'''
    job = db.query(Job).filter(Job.id == id, Job.owner_id == user_info.get("id")).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found or access unauthorized")

    db.delete(job)
    db.commit()
    return {"message": "Job deleted successfully"}

@router.post("/job/download")
def download_job(job_id: int, authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    if user_info.get("role") != "recruiter":
        raise HTTPException(status_code=403, detail="Access restricted to recruiters only")

    job = db.query(Job).filter(Job.id == job_id, Job.owner_id == user_info.get("id")).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found or access unauthorized")

    pdf = FPDF()
    pdf.add_page()
    pdf.set_font("Arial", "B", 12)
    pdf.cell(0, 10, f"Job Title: {job.title}", ln=True)
    pdf.set_font("Arial", "", 10)
    pdf.cell(0, 10, f"Description: {job.description}", ln=True)
    pdf.cell(0, 10, f"Skills: {job.skills}", ln=True)
    pdf.cell(0, 10, f"Experience: {job.experience}", ln=True)
    pdf.cell(0, 10, f"Education: {job.education}", ln=True)
    pdf.cell(0, 10, f"Languages: {job.languages if job.languages else 'N/A'}", ln=True)
    pdf.cell(0, 10, f"Contract Type: {job.contract_type}", ln=True)
    pdf.cell(0, 10, f"Salary: {job.salary if job.salary else 'N/A'}", ln=True)
    pdf.cell(0, 10, f"Location: {job.location if job.location else 'N/A'}", ln=True)
    pdf.cell(0, 10, f"Published: {'Yes' if job.is_published else 'No'}", ln=True)

    pdf_output = pdf.output(dest="S").encode("latin1")
    return Response(
        content=pdf_output,
        media_type="application/pdf",
        headers={"Content-Disposition": f"attachment; filename=job_{job_id}.pdf"}
    )

@router.get("/job/{id}")
def get_job(id: int, authorization: str = Header(...), db: Session = Depends(get_db)):
    print(f"Fetching Job with ID: {id}")

    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

   
    '''if user_info.get("role") != "recruiter":
        raise HTTPException(status_code=403, detail="Access restricted to recruiters only")'''

    # Rechercher le job par ID
    job = db.query(Job).filter(Job.id == id).first()
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")

    print(f"Job found: {job}")

    # Génération dynamique du champ `text`
    job_text = f"{job.title} {job.description} {job.skills} {job.experience} {job.education} {job.languages or ''} {job.contract_type or ''} {job.location or ''}".strip()

    return {
        "id": job.id,
        "owner_id": job.owner_id,
        "title": job.title,
        "description": job.description,
        "skills": job.skills,
        "experience": job.experience,
        "education": job.education,
        "languages": job.languages,
        "contract_type": job.contract_type,
        "salary": job.salary,
        "location": job.location,
        "is_published": job.is_published,
        "text": job_text,  
    }

@router.get("/jobs", summary="Get all jobs from the database")
def get_all_jobs(db: Session = Depends(get_db)):
    jobs = db.query(Job).all()
    return [
        {
            **job.__dict__,
            "text": f"{job.title}. {job.description}. {job.skills}. {job.location}. {job.languages}."
        }
        for job in jobs
    ]

@router.get("/filtered-jobs", summary="Get jobs created by the connected recruiter")
def get_jobs(authorization: str = Header(...), db: Session = Depends(get_db)):
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Invalid token format")
    token = authorization.split(" ")[1]
    user_info = verify_user_exists(token)

    # Vérifie que l'utilisateur est bien un recruteur
    if user_info.get("role") != "recruiter":
        raise HTTPException(status_code=403, detail="Access restricted to recruiters only")

    # Filtre les offres créées par ce recruteur
    jobs = db.query(Job).filter(Job.owner_id == user_info.get("id")).all()
    return [
        {
            **job.__dict__,
            "text": f"{job.title}. {job.description}. {job.skills}. {job.location}. {job.languages or ''}."
        }
        for job in jobs
    ]
